import os
from datetime import datetime

LOG_FILE = os.path.join(os.path.dirname(__file__), 'app.log')

def log(message, level='INFO'):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] [{level}] {message}\n"
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(line)
