import os
import pandas as pd
from datetime import datetime

DATA_DIR = os.path.dirname(__file__)
INVOICE_DIR = os.path.join(DATA_DIR, 'invoices')
os.makedirs(INVOICE_DIR, exist_ok=True)

def ensure_csv(path, headers):
    if not os.path.exists(path):
        import csv
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)

def next_id(df, col='id'):
    if df.empty:
        return 1
    return int(df[col].max()) + 1

def filter_df(df, q, cols=None):
    if not q:
        return df
    q = str(q).lower()
    cols = cols or list(df.columns)
    mask = False
    for c in cols:
        mask = mask | df[c].astype(str).str.lower().str.contains(q, na=False)
    return df[mask]

def make_invoice_html(order, user, items):
    # order: dict, user: dict, items: list of dicts
    total = sum(float(i['price']) * int(i['qty']) for i in items)
    dt = datetime.now().strftime('%Y-%m-%d %H:%M')
    rows = ''.join([f"<tr><td>{i['product_name']}</td><td>{i['qty']}</td><td>{i['price']}</td><td>{float(i['price'])*int(i['qty']):.2f}</td></tr>"
                    for i in items])
    html = f"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Invoice #{order['id']}</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 2rem; }}
    h1 {{ margin-bottom: 0; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ccc; padding: 8px; text-align: left; }}
    tfoot td {{ font-weight: bold; }}
    .muted {{ color: #555; }}
  </style>
</head>
<body>
  <h1>Easy Café</h1>
  <div class="muted">Invoice #{order['id']} • {dt}</div>
  <h3>Customer</h3>
  <p>{user.get('full_name','')}<br>{user.get('email','')}</p>
  <h3>Items</h3>
  <table>
    <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead>
    <tbody>
      {rows}
    </tbody>
    <tfoot>
      <tr><td colspan="3">Total</td><td>{total:.2f}</td></tr>
    </tfoot>
  </table>
  <p class="muted">Thank you for your order!</p>
</body>
</html>
"""
    return html

def save_invoice(order, user, items):
    html = make_invoice_html(order, user, items)
    path = os.path.join(INVOICE_DIR, f"invoice_{order['id']}.html")
    with open(path, 'w', encoding='utf-8') as f:
        f.write(html)
    return path
